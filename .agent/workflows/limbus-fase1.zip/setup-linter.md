# Workflow: Setup ESLint + Prettier

## Contexto
Este workflow adiciona linting e formatação automática ao projeto Limbus. São configurações separadas para o backend (Node.js) e o frontend (JS do browser), respeitando as diferenças entre os dois ambientes.

Os arquivos já estão em `.agent/workflows/` prontos para uso.

---

## Passo 1 — Criar configs do backend

Copiar os seguintes arquivos:

```
origem:  .agent/workflows/backend-.eslintrc.js    →   destino: backend/.eslintrc.js
origem:  .agent/workflows/backend-.prettierrc     →   destino: backend/.prettierrc
origem:  .agent/workflows/backend-.eslintignore   →   destino: backend/.eslintignore
```

---

## Passo 2 — Criar configs do frontend

Copiar os seguintes arquivos:

```
origem:  .agent/workflows/js-.eslintrc.js   →   destino: js/.eslintrc.js
origem:  .agent/workflows/js-.prettierrc    →   destino: js/.prettierrc
```

---

## Passo 3 — Atualizar backend/package.json

Substituir o arquivo:

```
origem:  .agent/workflows/package-backend.json
destino: backend/package.json
```

Este arquivo já contém jest + supertest (do workflow anterior) e agora adiciona:
- `"lint": "eslint . --ext .js"`
- `"lint:fix": "eslint . --ext .js --fix"`
- `"format": "prettier --write \"**/*.js\""`
- devDependencies: `eslint ^8.57.0` e `prettier ^3.3.3`

---

## Passo 4 — Atualizar package.json da raiz

Substituir o arquivo:

```
origem:  .agent/workflows/package.json
destino: package.json
```

Adiciona atalhos `npm run lint` e `npm run lint:fix` que delegam para o backend.

---

## Passo 5 — Instalar as novas dependências

```bash
cd backend
npm install
cd ..
```

---

## Passo 6 — Rodar o lint pela primeira vez

```bash
cd backend
npm run lint
```

É esperado que existam alguns warnings ou erros na primeira rodada. Para corrigir automaticamente o que for possível:

```bash
npm run lint:fix
```

---

## Passo 7 — Rodar os testes para garantir que nada quebrou

```bash
npm test
```

Todos os testes devem continuar passando após o lint:fix.

---

## Passo 8 — Commit

```bash
git add backend/.eslintrc.js backend/.prettierrc backend/.eslintignore
git add backend/package.json backend/package-lock.json
git add js/.eslintrc.js js/.prettierrc
git add package.json
git commit -m "chore: add ESLint + Prettier for backend and frontend"
```

---

## Estrutura final esperada

```
Limbus/
├── package.json              ← atualizado (atalhos lint)
├── js/
│   ├── .eslintrc.js          ← novo (config browser)
│   └── .prettierrc           ← novo
└── backend/
    ├── .eslintrc.js          ← novo (config Node)
    ├── .prettierrc           ← novo
    ├── .eslintignore         ← novo
    └── package.json          ← atualizado (eslint + prettier)
```

---

## Notas para o agente

- Os arquivos de config têm nomes prefixados com `backend-` e `js-` para não conflitar na pasta de workflows — renomear corretamente no destino (remover o prefixo, manter o ponto inicial)
- O ESLint do frontend tem a lista de globais do projeto declarada — se novas funções forem adicionadas ao `store.js` ou `ui.js` no futuro, adicionar aqui também
- O `printWidth: 200` no frontend é intencional — template literals com HTML inline tornam limite menor impossível de respeitar
- Não rodar `prettier --write` no frontend manualmente agora — os template strings HTML podem ser reformatados de forma inesperada
