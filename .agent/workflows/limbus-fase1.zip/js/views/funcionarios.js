// js/views/funcionarios.js

const renderFuncionarios = (container, headerActions) => {
    headerActions.innerHTML = `
        <div class="flex flex-wrap items-center gap-4">
            <div class="relative">
                <i data-lucide="search" class="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"></i>
                <input type="text" id="search-func" placeholder="Buscar funcionário..." class="pl-9 pr-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none w-64 lg:w-80 dark:text-slate-100 dark:bg-slate-900">
            </div>
            <button id="btn-import-planilha" class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg font-medium transition-colors shadow-sm inline-flex items-center gap-2">
                <i data-lucide="file-spreadsheet" class="w-4 h-4"></i>
                Importar Planilha
            </button>
            <button id="btn-add-func" class="btn-primary">
                <i data-lucide="user-plus" class="w-4 h-4"></i>
                Novo Funcionário
            </button>
        </div>
    `;

    const renderTable = (filterText = '') => {
        let funcionarios = getFuncionarios();
        if (filterText) {
            const lowerFilter = filterText.toLowerCase();
            funcionarios = funcionarios.filter(f =>
                f.nome.toLowerCase().includes(lowerFilter) ||
                f.funcao.toLowerCase().includes(lowerFilter)
            );
        }
        let tableHTML = `
            <div class="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-slate-50 dark:bg-slate-900/50 text-slate-500 dark:text-slate-400 text-sm border-b border-slate-200 dark:border-slate-700">
                            <th class="py-3 px-6 font-semibold">Nome Completo</th>
                            <th class="py-3 px-6 font-semibold">Função/Cargo</th>
                            <th class="py-3 px-6 font-semibold">Data Admissão</th>
                            <th class="py-3 px-6 font-semibold text-right">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        if (funcionarios.length === 0) {
            tableHTML += `<tr><td colspan="4" class="py-6 text-center text-slate-500 dark:text-slate-400">Nenhum funcionário cadastrado. Clique no botão acima para adicionar.</td></tr>`;
        } else {
            funcionarios.forEach(f => {
                tableHTML += `
                    <tr class="border-b border-slate-100 hover:bg-slate-50 dark:bg-slate-900/50 transition-colors">
                        <td class="py-4 px-6 font-medium text-slate-800 dark:text-slate-100">${f.nome}</td>
                        <td class="py-4 px-6 text-slate-600 dark:text-slate-300">${f.funcao}</td>
                        <td class="py-4 px-6 text-slate-600 dark:text-slate-300">${formatInputDate(f.dataAdmissao)}</td>
                        <td class="py-4 px-6 text-right flex justify-end gap-2">
                            <button onclick="renderFuncionarioPerfil('${f.id}')" class="bg-blue-50 text-blue-700 hover:bg-blue-100 px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center gap-1" title="Visualizar Histórico e Devoluções">
                                <i data-lucide="clock" class="w-4 h-4"></i> Perfil
                            </button>
                            <button onclick="navigate('gerador_termo', { funcId: '${f.id}' })" class="bg-emerald-100 text-emerald-700 hover:bg-emerald-200 px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center gap-1">
                                <i data-lucide="file-text" class="w-4 h-4"></i> Gerar Termo
                            </button>
                            <button data-id="${f.id}" class="btn-edit-func text-slate-500 hover:text-blue-600 p-1.5 rounded-md hover:bg-blue-50 transition-colors" title="Editar">
                                <i data-lucide="pencil" class="w-4 h-4"></i>
                            </button>
                            <button data-id="${f.id}" class="btn-delete-func text-red-500 hover:text-red-700 p-1.5 rounded-md hover:bg-red-50 transition-colors" title="Remover">
                                <i data-lucide="trash-2" class="w-4 h-4"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
        }

        tableHTML += `</tbody></table></div>`;
        container.innerHTML = tableHTML;

        if (window.lucide) window.lucide.createIcons();

        document.querySelectorAll('.btn-delete-func').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const id = e.currentTarget.dataset.id;
                const ok = await showConfirm('Remover funcionário? Isso não apagará termos já gerados, mas o removerá da base.', { title: 'Remover funcionário', type: 'danger', confirmText: 'Remover' });
                if (ok) {
                    await removeFuncionario(id);
                    showToast('Funcionário removido com sucesso.', 'success');
                    renderTable();
                }
            });
        });

        document.querySelectorAll('.btn-edit-func').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.currentTarget.dataset.id;
                const func = getFuncionarioById(id);
                if (!func) return;

                const formHTML = `
                    <div class="p-6">
                        <h3 class="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4">Editar Funcionário</h3>
                        <form id="form-edit-func" class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1">Nome Completo</label>
                                <input type="text" name="nome" required value="${func.nome}" class="w-full border border-slate-300 dark:border-slate-600 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:border-primary outline-none dark:text-slate-100 dark:bg-slate-900">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1">Função / Cargo</label>
                                <input type="text" name="funcao" required value="${func.funcao}" class="w-full border border-slate-300 dark:border-slate-600 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:border-primary outline-none dark:text-slate-100 dark:bg-slate-900">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1">Data de Admissão</label>
                                <input type="date" name="dataAdmissao" required value="${func.dataAdmissao}" class="w-full border border-slate-300 dark:border-slate-600 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:border-primary outline-none dark:text-slate-100 dark:bg-slate-900">
                            </div>
                            <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-slate-100">
                                <button type="button" class="btn-cancel bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 px-4 py-2 rounded-lg font-medium hover:bg-slate-50 dark:bg-slate-900/50 transition-colors">Cancelar</button>
                                <button type="submit" class="btn-primary">Salvar Alterações</button>
                            </div>
                        </form>
                    </div>
                `;

                showModal(formHTML);

                document.getElementById('form-edit-func').addEventListener('submit', async (ev) => {
                    ev.preventDefault();
                    const formData = new FormData(ev.target);
                    await editFuncionario(id, {
                        nome: formData.get('nome'),
                        funcao: formData.get('funcao'),
                        dataAdmissao: formData.get('dataAdmissao')
                    });
                    hideModal();
                    renderTable(document.getElementById('search-func')?.value || '');
                });
                document.querySelector('.btn-cancel').addEventListener('click', hideModal);
            });
        });
    };

    renderTable();

    document.getElementById('search-func').addEventListener('input', debounce((e) => {
        renderTable(e.target.value);
    }, 300));

    document.getElementById('btn-add-func').addEventListener('click', () => {
        const formHTML = `
            <div class="p-6">
                <h3 class="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4">Cadastrar Funcionário</h3>
                <form id="form-func" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1">Nome Completo</label>
                        <input type="text" name="nome" required class="w-full border border-slate-300 dark:border-slate-600 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:border-primary outline-none dark:text-slate-100 dark:bg-slate-900">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1">Função / Cargo</label>
                        <input type="text" name="funcao" required class="w-full border border-slate-300 dark:border-slate-600 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:border-primary outline-none dark:text-slate-100 dark:bg-slate-900">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1">Data de Admissão</label>
                        <input type="date" name="dataAdmissao" required class="w-full border border-slate-300 dark:border-slate-600 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:border-primary outline-none dark:text-slate-100 dark:bg-slate-900">
                    </div>
                    <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-slate-100">
                        <button type="button" class="btn-cancel bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 px-4 py-2 rounded-lg font-medium hover:bg-slate-50 dark:bg-slate-900/50 transition-colors">Cancelar</button>
                        <button type="submit" class="btn-primary">Salvar</button>
                    </div>
                </form>
            </div>
        `;

        showModal(formHTML);

        document.getElementById('form-func').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            await addFuncionario({
                nome: formData.get('nome'),
                funcao: formData.get('funcao'),
                dataAdmissao: formData.get('dataAdmissao')
            });
            hideModal();
            renderTable(document.getElementById('search-func')?.value || '');
        });
        document.querySelector('.btn-cancel').addEventListener('click', hideModal);
    });

    // --- Importar Planilha ---
    document.getElementById('btn-import-planilha').addEventListener('click', () => {
        const modalHTML = `
            <div class="p-6 max-h-[85vh] flex flex-col">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h3 class="text-xl font-bold text-slate-800 dark:text-slate-100">Importar Planilha</h3>
                        <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Importe funcionários de um arquivo Excel (.xlsx, .xls) ou CSV.</p>
                    </div>
                    <button onclick="hideModal()" class="text-slate-400 hover:text-slate-600 dark:text-slate-300 p-1"><i data-lucide="x" class="w-5 h-5"></i></button>
                </div>

                <div id="import-step-upload">
                    <div id="dropzone" class="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-xl p-12 text-center cursor-pointer hover:border-primary hover:bg-blue-50/50 dark:hover:bg-blue-900/10 transition-all">
                        <i data-lucide="upload-cloud" class="w-12 h-12 text-slate-400 mx-auto mb-4"></i>
                        <p class="text-slate-700 dark:text-slate-200 font-medium mb-1">Arraste seu arquivo aqui</p>
                        <p class="text-sm text-slate-500 dark:text-slate-400">ou clique para selecionar</p>
                        <p class="text-xs text-slate-400 mt-3">Formatos aceitos: .xlsx, .xls, .csv</p>
                        <input type="file" id="file-input-planilha" accept=".xlsx,.xls,.csv" class="hidden">
                    </div>
                    <div id="import-error" class="hidden mt-4 bg-red-50 text-red-700 p-3 rounded-lg text-sm border border-red-200"></div>
                </div>

                <div id="import-step-preview" class="hidden flex flex-col flex-1 overflow-hidden">
                    <div id="import-file-info" class="bg-emerald-50 text-emerald-800 p-3 rounded-lg mb-4 text-sm border border-emerald-200 flex items-center gap-2">
                        <i data-lucide="file-check" class="w-4 h-4"></i>
                        <span id="import-file-name"></span>
                    </div>
                    <div id="import-sheets-container" class="overflow-y-auto flex-1 space-y-3 mb-4"></div>
                    <div id="import-summary" class="bg-blue-50 text-blue-800 p-3 rounded-lg text-sm border border-blue-200 mb-4">
                        <span id="import-total-count"></span>
                    </div>
                    <div class="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-700">
                        <button id="btn-import-back" class="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 px-4 py-2 rounded-lg font-medium hover:bg-slate-50 dark:hover:bg-slate-900/50 transition-colors">Voltar</button>
                        <button id="btn-import-confirm" class="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 rounded-lg font-medium transition-colors shadow-sm inline-flex items-center gap-2">
                            <i data-lucide="download" class="w-4 h-4"></i>
                            Importar
                        </button>
                    </div>
                </div>

                <div id="import-step-result" class="hidden text-center py-8">
                    <div class="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i data-lucide="check-circle" class="w-8 h-8"></i>
                    </div>
                    <h4 class="text-lg font-bold text-slate-800 dark:text-slate-100 mb-2" id="import-result-title"></h4>
                    <p class="text-sm text-slate-500 dark:text-slate-400 mb-6" id="import-result-desc"></p>
                    <button onclick="hideModal()" class="btn-primary">Fechar</button>
                </div>
            </div>
        `;

        showModal(modalHTML);
        if (window.lucide) window.lucide.createIcons();

        let parsedSheets = [];

        const dropzone = document.getElementById('dropzone');
        const fileInput = document.getElementById('file-input-planilha');
        const errorDiv = document.getElementById('import-error');

        const excelDateToString = (serial) => {
            if (!serial) return '';
            if (typeof serial === 'string') {
                const parts = serial.match(/(\d{2})\/(\d{2})\/(\d{4})/);
                if (parts) return `${parts[3]}-${parts[2]}-${parts[1]}`;
                if (/^\d{4}-\d{2}-\d{2}$/.test(serial)) return serial;
                return serial;
            }
            if (typeof serial === 'number') {
                const utcDays = Math.floor(serial - 25569);
                const utcValue = utcDays * 86400;
                const date = new Date(utcValue * 1000);
                const yyyy = date.getUTCFullYear();
                const mm = String(date.getUTCMonth() + 1).padStart(2, '0');
                const dd = String(date.getUTCDate()).padStart(2, '0');
                return `${yyyy}-${mm}-${dd}`;
            }
            return '';
        };

        const findColumnIndex = (headers, ...keywords) => {
            return headers.findIndex(h => {
                if (!h) return false;
                const normalized = String(h).trim().toUpperCase()
                    .normalize('NFD').replace(/[\u0300-\u036f]/g, '');
                return keywords.some(kw => normalized.includes(kw));
            });
        };

        const processFile = (file) => {
            errorDiv.classList.add('hidden');
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, { type: 'array' });

                    parsedSheets = [];

                    workbook.SheetNames.forEach(sheetName => {
                        const sheet = workbook.Sheets[sheetName];
                        const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });

                        if (jsonData.length < 2) return;

                        let headerRowIdx = -1;
                        for (let i = 0; i < Math.min(5, jsonData.length); i++) {
                            const row = jsonData[i];
                            const hasNome = row.some(cell => {
                                const val = String(cell).trim().toUpperCase()
                                    .normalize('NFD').replace(/[\u0300-\u036f]/g, '');
                                return val === 'NOME';
                            });
                            if (hasNome) { headerRowIdx = i; break; }
                        }

                        if (headerRowIdx === -1) return;

                        const headers = jsonData[headerRowIdx];
                        const nomeIdx = findColumnIndex(headers, 'NOME');
                        const setorIdx = findColumnIndex(headers, 'SETOR', 'FUNCAO', 'CARGO', 'DEPARTAMENTO');
                        const admissaoIdx = findColumnIndex(headers, 'ADMISSAO', 'DATA', 'ADMISSÃO');

                        if (nomeIdx === -1) return;

                        const rows = jsonData.slice(headerRowIdx + 1);
                        const employees = [];

                        rows.forEach(row => {
                            const nome = row[nomeIdx] ? String(row[nomeIdx]).trim() : '';
                            if (!nome) return;
                            const funcao = setorIdx !== -1 && row[setorIdx] ? String(row[setorIdx]).trim() : 'Não Informado';
                            const dataRaw = admissaoIdx !== -1 ? row[admissaoIdx] : '';
                            const dataAdmissao = excelDateToString(dataRaw) || new Date().toISOString().split('T')[0];
                            employees.push({ nome, funcao, dataAdmissao });
                        });

                        if (employees.length > 0) {
                            parsedSheets.push({ name: sheetName, data: employees, selected: true });
                        }
                    });

                    if (parsedSheets.length === 0) {
                        errorDiv.textContent = 'Não foi possível encontrar dados válidos. Verifique se a planilha possui colunas NOME, ADMISSÃO e SETOR.';
                        errorDiv.classList.remove('hidden');
                        return;
                    }

                    showPreview(file.name);
                } catch (err) {
                    console.error('Erro ao processar planilha:', err);
                    errorDiv.textContent = 'Erro ao ler o arquivo. Verifique se é um Excel válido.';
                    errorDiv.classList.remove('hidden');
                }
            };
            reader.readAsArrayBuffer(file);
        };

        const showPreview = (fileName) => {
            document.getElementById('import-step-upload').classList.add('hidden');
            document.getElementById('import-step-preview').classList.remove('hidden');
            document.getElementById('import-file-name').textContent = fileName;
            renderSheetsPreview();
        };

        const renderSheetsPreview = () => {
            const sheetsContainer = document.getElementById('import-sheets-container');
            const existingNames = getFuncionarios().map(f => f.nome.trim().toUpperCase());

            sheetsContainer.innerHTML = parsedSheets.map((sheet, idx) => {
                const newCount = sheet.data.filter(e => !existingNames.includes(e.nome.toUpperCase())).length;
                const dupCount = sheet.data.length - newCount;
                const previewNames = sheet.data.slice(0, 4).map(e => e.nome).join(', ');
                const moreCount = sheet.data.length - 4;

                return `
                    <div class="border border-slate-200 dark:border-slate-700 rounded-lg p-4 ${sheet.selected ? 'bg-emerald-50/50 dark:bg-emerald-900/10 border-emerald-300 dark:border-emerald-700' : 'bg-white dark:bg-slate-800 opacity-60'}">
                        <label class="flex items-start gap-3 cursor-pointer">
                            <input type="checkbox" data-sheet-idx="${idx}" class="sheet-checkbox mt-1 w-4 h-4 text-emerald-600 border-slate-300 dark:border-slate-600 rounded focus:ring-emerald-500" ${sheet.selected ? 'checked' : ''}>
                            <div class="flex-1">
                                <div class="flex items-center gap-2 mb-1">
                                    <span class="font-semibold text-slate-800 dark:text-slate-100">${sheet.name}</span>
                                    <span class="text-xs bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-full">${sheet.data.length} registros</span>
                                    ${dupCount > 0 ? `<span class="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">${dupCount} já cadastrados</span>` : ''}
                                </div>
                                <p class="text-xs text-slate-500 dark:text-slate-400">${previewNames}${moreCount > 0 ? ` e mais ${moreCount}...` : ''}</p>
                            </div>
                        </label>
                    </div>
                `;
            }).join('');

            updateImportCount();

            sheetsContainer.querySelectorAll('.sheet-checkbox').forEach(cb => {
                cb.addEventListener('change', (e) => {
                    const idx = parseInt(e.target.dataset.sheetIdx);
                    parsedSheets[idx].selected = e.target.checked;
                    renderSheetsPreview();
                });
            });
        };

        const updateImportCount = () => {
            const existingNames = getFuncionarios().map(f => f.nome.trim().toUpperCase());
            let totalNew = 0;
            parsedSheets.forEach(sheet => {
                if (sheet.selected) {
                    totalNew += sheet.data.filter(e => !existingNames.includes(e.nome.toUpperCase())).length;
                }
            });
            document.getElementById('import-total-count').innerHTML = `<strong>${totalNew}</strong> novos funcionários serão importados (duplicados serão ignorados).`;
            const btnConfirm = document.getElementById('btn-import-confirm');
            if (totalNew === 0) {
                btnConfirm.disabled = true;
                btnConfirm.classList.add('opacity-50', 'cursor-not-allowed');
            } else {
                btnConfirm.disabled = false;
                btnConfirm.classList.remove('opacity-50', 'cursor-not-allowed');
            }
        };

        dropzone.addEventListener('click', () => fileInput.click());
        dropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropzone.classList.add('border-primary', 'bg-blue-50', 'dark:bg-blue-900/20');
        });
        dropzone.addEventListener('dragleave', () => {
            dropzone.classList.remove('border-primary', 'bg-blue-50', 'dark:bg-blue-900/20');
        });
        dropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropzone.classList.remove('border-primary', 'bg-blue-50', 'dark:bg-blue-900/20');
            const file = e.dataTransfer.files[0];
            if (file) processFile(file);
        });
        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) processFile(file);
        });

        document.getElementById('btn-import-back')?.addEventListener('click', () => {
            document.getElementById('import-step-preview').classList.add('hidden');
            document.getElementById('import-step-upload').classList.remove('hidden');
            parsedSheets = [];
        });

        document.getElementById('btn-import-confirm')?.addEventListener('click', async () => {
            const existingNames = getFuncionarios().map(f => f.nome.trim().toUpperCase());
            const toImport = [];

            parsedSheets.forEach(sheet => {
                if (!sheet.selected) return;
                sheet.data.forEach(emp => {
                    if (!existingNames.includes(emp.nome.toUpperCase())) {
                        toImport.push(emp);
                        existingNames.push(emp.nome.toUpperCase());
                    }
                });
            });

            if (toImport.length === 0) {
                showToast('Nenhum funcionário novo para importar.', 'warning');
                return;
            }

            const btnConfirm = document.getElementById('btn-import-confirm');
            btnConfirm.disabled = true;
            btnConfirm.innerHTML = '<i data-lucide="loader-2" class="w-4 h-4 animate-spin"></i> Importando...';
            if (window.lucide) window.lucide.createIcons();

            const result = await bulkAddFuncionarios(toImport);

            document.getElementById('import-step-preview').classList.add('hidden');
            document.getElementById('import-step-result').classList.remove('hidden');
            document.getElementById('import-result-title').textContent = `${result.count} funcionários importados!`;
            document.getElementById('import-result-desc').textContent = `Os funcionários foram adicionados ao sistema com sucesso.`;
            if (window.lucide) window.lucide.createIcons();

            renderTable(document.getElementById('search-func')?.value || '');
        });
    });
};

// --- Perfil do Funcionário (Histórico & Devolução) ---
window.renderFuncionarioPerfil = (id) => {
    const funcionario = getFuncionarioById(id);
    const equipamentos = getEquipamentos();
    const equipamentosEmPosse = equipamentos.filter(e => e.funcionarioId === id && e.status === 'EM_USO');
    const historico = getHistorico().filter(h => h.funcionarioId === id).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    const historicoHTML = historico.length === 0
        ? '<p class="text-sm text-slate-500 dark:text-slate-400 py-4 text-center">Nenhum registro no histórico.</p>'
        : historico.map(h => {
            const dataStr = formatInputDate(h.data);
            const timeStr = new Date(h.timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

            let icone = '', corTexto = '', bgIcone = '', acao = '';
            if (h.tipo === 'ENTREGA' || h.tipo === 'ALOCACAO_MANUAL') {
                icone = 'arrow-down-right'; corTexto = 'text-emerald-700'; bgIcone = 'bg-emerald-100';
                acao = h.tipo === 'ENTREGA' ? 'Recebeu' : 'Alocação Manual';
            } else if (h.tipo === 'DEVOLUCAO' || h.tipo === 'DEVOLUCAO_COMPLETA') {
                icone = 'arrow-up-left'; corTexto = 'text-amber-700'; bgIcone = 'bg-amber-100'; acao = 'Devolveu';
            }

            let eqpContent = '';
            if (h.equipamentosIds && h.equipamentosIds.length > 0) {
                const eqps = h.equipamentosIds.map(eId => equipamentos.find(e => e.id === eId) || { descricao: 'Equipamento Excluído', modeloMarca: '' });
                eqpContent = `<p class="text-sm font-medium text-slate-800 dark:text-slate-100">${acao} múltiplos itens:</p>
                              <div class="mt-1 space-y-1 pl-2 border-l-2 border-slate-200 dark:border-slate-700">
                                ${eqps.map(eq => `<div><span class="font-bold text-slate-900 dark:text-slate-100">${eq.descricao}</span> <span class="text-xs text-slate-500 dark:text-slate-400">(${eq.modeloMarca})</span></div>`).join('')}
                              </div>`;
            } else {
                const eqp = equipamentos.find(e => e.id === h.equipamentoId) || { descricao: 'Equipamento Excluído', modeloMarca: '' };
                eqpContent = `<p class="text-sm font-medium text-slate-800 dark:text-slate-100">${acao} <span class="font-bold text-slate-900 dark:text-slate-100">${eqp.descricao}</span></p>
                              <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">${eqp.modeloMarca}</p>`;
            }

            return `
                <div class="flex gap-4 items-start relative pb-6 last:pb-0 before:absolute before:left-[15px] before:top-8 before:bottom-0 before:-ml-px before:w-0.5 before:bg-slate-200 last:before:hidden">
                    <div class="relative z-10 w-8 h-8 rounded-full ${bgIcone} flex items-center justify-center shrink-0 ring-4 ring-white">
                        <i data-lucide="${icone}" class="w-4 h-4 ${corTexto}"></i>
                    </div>
                    <div>
                        ${eqpContent}
                        <p class="text-xs text-slate-400 mt-1.5 flex items-center gap-1"><i data-lucide="calendar" class="w-3 h-3"></i> ${dataStr} às ${timeStr}</p>
                    </div>
                </div>
             `;
        }).join('');

    const posseHTML = equipamentosEmPosse.length === 0
        ? '<p class="text-sm text-slate-500 dark:text-slate-400 py-4 text-center border border-dashed border-slate-300 dark:border-slate-600 rounded-lg">Nenhum equipamento em posse atualmente.</p>'
        : `<div class="space-y-3">
             ${equipamentosEmPosse.map(eqp => `
                <div class="flex items-center justify-between p-3 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center text-primary">
                            <i data-lucide="laptop" class="w-5 h-5"></i>
                        </div>
                        <div>
                            <p class="text-sm font-bold text-slate-800 dark:text-slate-100">${eqp.descricao}</p>
                            <p class="text-xs text-slate-500 dark:text-slate-400">${eqp.modeloMarca}</p>
                        </div>
                    </div>
                    <button data-eqpid="${eqp.id}" class="btn-devolver bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:bg-slate-900/50 hover:text-red-600 px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center gap-1" title="Registrar devolução do equipamento">
                        <i data-lucide="corner-up-left" class="w-4 h-4"></i> Devolver
                    </button>
                </div>
             `).join('')}
         </div>`;

    const html = `
        <div class="flex flex-col h-[85vh] max-h-[800px]">
            <div class="p-6 border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 shrink-0 flex justify-between items-start">
                <div>
                    <h3 class="text-2xl font-bold text-slate-800 dark:text-slate-100">${funcionario.nome}</h3>
                    <p class="text-slate-500 dark:text-slate-400">${funcionario.funcao} &bull; Admissão: ${formatInputDate(funcionario.dataAdmissao)}</p>
                </div>
                <button onclick="hideModal()" class="text-slate-400 hover:text-slate-600 dark:text-slate-300 p-1">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>
            
            <div class="p-6 overflow-y-auto flex-1 bg-slate-50 dark:bg-slate-900/50">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div>
                        <div class="flex items-center justify-between mb-4">
                            <div class="flex items-center gap-2">
                                <i data-lucide="box" class="w-5 h-5 text-primary"></i>
                                <h4 class="text-lg font-bold text-slate-800 dark:text-slate-100">Posse Atual</h4>
                            </div>
                            ${equipamentosEmPosse.length > 1 ? `
                            <button id="btn-devolver-todos" class="text-xs bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1 shadow-sm">
                                <i data-lucide="corner-up-left" class="w-3.5 h-3.5"></i> Devolver Todos
                            </button>
                            ` : ''}
                        </div>
                        ${posseHTML}
                    </div>

                    <div>
                        <div class="flex items-center gap-2 mb-4 pb-2 border-b border-slate-200 dark:border-slate-700">
                            <i data-lucide="history" class="w-5 h-5 text-slate-600 dark:text-slate-300"></i>
                            <h4 class="text-lg font-bold text-slate-800 dark:text-slate-100">Linha do Tempo</h4>
                        </div>
                        <div class="pl-2">
                            ${historicoHTML}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    showModal(html);
    if (window.lucide) window.lucide.createIcons();

    document.querySelectorAll('.btn-devolver').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const eqpId = e.currentTarget.dataset.eqpid;
            const eqp = getEquipamentoById(eqpId);

            const ok = await showConfirm(`Confirmar devolução de ${eqp.descricao}? O equipamento ficará disponível no estoque.`, { title: 'Devolver equipamento', confirmText: 'Devolver' });
            if (ok) {
                await editEquipamento(eqpId, { status: 'DISPONIVEL', funcionarioId: null });
                await addHistorico({
                    tipo: 'DEVOLUCAO',
                    funcionarioId: id,
                    equipamentoId: eqpId,
                    data: new Date().toISOString().split('T')[0]
                });

                window.renderFuncionarioPerfil(id);

                const currentView = document.querySelector('a.nav-btn.active')?.dataset.view;
                if (currentView === 'funcionarios') {
                    renderFuncionarios(document.getElementById('content-area'), document.getElementById('header-actions'));
                } else if (currentView === 'equipamentos') {
                    renderEquipamentos(document.getElementById('content-area'), document.getElementById('header-actions'));
                }
            }
        });
    });

    const btnDevolverTodos = document.getElementById('btn-devolver-todos');
    if (btnDevolverTodos) {
        btnDevolverTodos.addEventListener('click', async () => {
            const okAll = await showConfirm('Confirmar devolução COMPLETA de todos os equipamentos em posse deste funcionário?', { title: 'Devolução completa', type: 'danger', confirmText: 'Devolver Todos' });
            if (okAll) {
                const todayStrInput = new Date().toISOString().split('T')[0];
                const dataRealStr = formatInputDate(todayStrInput);
                const timeStr = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

                for (const eqp of equipamentosEmPosse) {
                    await editEquipamento(eqp.id, { status: 'DISPONIVEL', funcionarioId: null });
                }

                await addHistorico({
                    tipo: 'DEVOLUCAO_COMPLETA',
                    funcionarioId: id,
                    equipamentosIds: equipamentosEmPosse.map(e => e.id),
                    data: todayStrInput
                });

                const printWindow = window.open('', '_blank');
                if (printWindow) {
                    const html = `
                    <!DOCTYPE html>
                    <html lang="pt-BR">
                    <head>
                        <meta charset="UTF-8">
                        <title>Recibo de Devolução - ${funcionario.nome}</title>
                        <style>
                            body { font-family: 'Segoe UI', Arial, sans-serif; padding: 40px; color: #1e293b; line-height: 1.5; }
                            .header { text-align: center; border-bottom: 2px solid #e2e8f0; padding-bottom: 20px; margin-bottom: 30px; }
                            .header h1 { margin: 0; font-size: 24px; color: #0f172a; text-transform: uppercase; letter-spacing: 1px; }
                            .header p { margin: 5px 0 0; color: #64748b; }
                            .info-box { background: #f8fafc; border: 1px solid #e2e8f0; padding: 20px; border-radius: 8px; margin-bottom: 30px; }
                            .info-box p { margin: 5px 0; }
                            table { width: 100%; border-collapse: collapse; margin-bottom: 40px; }
                            th, td { border: 1px solid #cbd5e1; padding: 12px; text-align: left; }
                            th { background-color: #f1f5f9; font-weight: bold; text-transform: uppercase; font-size: 12px; color: #475569; }
                            td { font-size: 14px; }
                            .signatures { margin-top: 80px; display: flex; justify-content: space-between; }
                            .signature-line { width: 45%; border-top: 1px solid #000; text-align: center; padding-top: 10px; }
                            .signature-line p { margin: 0; font-weight: bold; font-size: 14px; }
                            .signature-line span { font-size: 12px; color: #64748b; }
                            @media print { body { padding: 0; margin: 1cm; } }
                        </style>
                    </head>
                    <body onload="window.print()">
                        <div class="header">
                            <h1>Recibo de Devolução Completa</h1>
                            <p>Limbus - Gestão de Equipamentos</p>
                        </div>
                        <div class="info-box">
                            <p><strong>Devolvido por:</strong> ${funcionario.nome}</p>
                            <p><strong>Função/Cargo:</strong> ${funcionario.funcao}</p>
                            <p><strong>Data e Hora da Devolução:</strong> ${dataRealStr} às ${timeStr}</p>
                        </div>
                        <h3>Itens Devolvidos</h3>
                        <table>
                            <thead>
                                <tr>
                                    <th>Equipamento</th>
                                    <th>Modelo / Marca</th>
                                    <th>Status Recebido</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${equipamentosEmPosse.map(eqp => `
                                    <tr>
                                        <td><strong>${eqp.descricao}</strong></td>
                                        <td>${eqp.modeloMarca}</td>
                                        <td>(   ) OK  (   ) Avariado</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                        <div class="signatures">
                            <div class="signature-line">
                                <p>${funcionario.nome}</p>
                                <span>Assinatura do Funcionário</span>
                            </div>
                            <div class="signature-line">
                                <p>Responsável TI</p>
                                <span>Assinatura do Recebedor</span>
                            </div>
                        </div>
                    </body>
                    </html>
                    `;
                    printWindow.document.write(html);
                    printWindow.document.close();
                } else {
                    showToast('Equipamentos devolvidos, mas não foi possível abrir o Recibo (pop-up bloqueado).', 'warning');
                }

                window.renderFuncionarioPerfil(id);
                const currentView = document.querySelector('a.nav-btn.active')?.dataset.view;
                if (currentView === 'funcionarios') {
                    renderFuncionarios(document.getElementById('content-area'), document.getElementById('header-actions'));
                } else if (currentView === 'equipamentos') {
                    renderEquipamentos(document.getElementById('content-area'), document.getElementById('header-actions'));
                }
            }
        });
    }
};
